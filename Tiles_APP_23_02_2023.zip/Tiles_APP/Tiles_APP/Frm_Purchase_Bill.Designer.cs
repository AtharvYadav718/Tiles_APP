﻿namespace Tiles_APP
{
    partial class Frm_Purchase_Bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Supplier_Name = new System.Windows.Forms.TextBox();
            this.lbl_Supplier_Name = new System.Windows.Forms.Label();
            this.tb_Purchase_ID = new System.Windows.Forms.TextBox();
            this.lbl_Purchase_ID = new System.Windows.Forms.Label();
            this.tb_Sup_Inv_No = new System.Windows.Forms.TextBox();
            this.lbl_Sup_Inv_No = new System.Windows.Forms.Label();
            this.gb_Product_Details = new System.Windows.Forms.GroupBox();
            this.dtp_Purchase_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_Purchase_Date = new System.Windows.Forms.Label();
            this.tb_Sales_Price = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_Purchase_Price = new System.Windows.Forms.TextBox();
            this.lbl_Purchase_Price = new System.Windows.Forms.Label();
            this.tb_Quantity = new System.Windows.Forms.TextBox();
            this.lbl_Quantity = new System.Windows.Forms.Label();
            this.tb_Purchase_Unit = new System.Windows.Forms.TextBox();
            this.lbl_Purchase_Unit = new System.Windows.Forms.Label();
            this.btn_Add = new System.Windows.Forms.Button();
            this.tb_Product_Name = new System.Windows.Forms.TextBox();
            this.lbl_Product_Name = new System.Windows.Forms.Label();
            this.cmb_Subcategory_Name = new System.Windows.Forms.ComboBox();
            this.lbl_Subcategory_Name = new System.Windows.Forms.Label();
            this.Cmb_Category_Name = new System.Windows.Forms.ComboBox();
            this.lbl_Category_Name = new System.Windows.Forms.Label();
            this.dgv_Purchase_Bill = new System.Windows.Forms.DataGridView();
            this.tb_Discount = new System.Windows.Forms.TextBox();
            this.lbl_Discount = new System.Windows.Forms.Label();
            this.lbl_GST = new System.Windows.Forms.Label();
            this.tb_GST = new System.Windows.Forms.TextBox();
            this.lbl_Total_Amount = new System.Windows.Forms.Label();
            this.tb_Total_Amount = new System.Windows.Forms.TextBox();
            this.lbl_Paid_Amount = new System.Windows.Forms.Label();
            this.tb_Paid_Amount = new System.Windows.Forms.TextBox();
            this.tb_Balance_Amount = new System.Windows.Forms.TextBox();
            this.lbl_Balance_Amount = new System.Windows.Forms.Label();
            this.cmb_Payment_Mode = new System.Windows.Forms.ComboBox();
            this.lbl_Payment_Mode = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Order_List = new System.Windows.Forms.Button();
            this.gb_Product_Details.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Purchase_Bill)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_Supplier_Name
            // 
            this.tb_Supplier_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Supplier_Name.Location = new System.Drawing.Point(879, 20);
            this.tb_Supplier_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Supplier_Name.Name = "tb_Supplier_Name";
            this.tb_Supplier_Name.Size = new System.Drawing.Size(381, 34);
            this.tb_Supplier_Name.TabIndex = 26;
            // 
            // lbl_Supplier_Name
            // 
            this.lbl_Supplier_Name.AutoSize = true;
            this.lbl_Supplier_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Supplier_Name.Location = new System.Drawing.Point(699, 24);
            this.lbl_Supplier_Name.Name = "lbl_Supplier_Name";
            this.lbl_Supplier_Name.Size = new System.Drawing.Size(166, 25);
            this.lbl_Supplier_Name.TabIndex = 25;
            this.lbl_Supplier_Name.Text = "Supplier Name ";
            // 
            // tb_Purchase_ID
            // 
            this.tb_Purchase_ID.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Purchase_ID.Location = new System.Drawing.Point(175, 20);
            this.tb_Purchase_ID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Purchase_ID.Name = "tb_Purchase_ID";
            this.tb_Purchase_ID.Size = new System.Drawing.Size(157, 34);
            this.tb_Purchase_ID.TabIndex = 22;
            // 
            // lbl_Purchase_ID
            // 
            this.lbl_Purchase_ID.AutoSize = true;
            this.lbl_Purchase_ID.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Purchase_ID.Location = new System.Drawing.Point(7, 24);
            this.lbl_Purchase_ID.Name = "lbl_Purchase_ID";
            this.lbl_Purchase_ID.Size = new System.Drawing.Size(144, 25);
            this.lbl_Purchase_ID.TabIndex = 21;
            this.lbl_Purchase_ID.Text = "Purchase ID ";
            // 
            // tb_Sup_Inv_No
            // 
            this.tb_Sup_Inv_No.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Sup_Inv_No.Location = new System.Drawing.Point(520, 20);
            this.tb_Sup_Inv_No.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Sup_Inv_No.Name = "tb_Sup_Inv_No";
            this.tb_Sup_Inv_No.Size = new System.Drawing.Size(157, 34);
            this.tb_Sup_Inv_No.TabIndex = 28;
            // 
            // lbl_Sup_Inv_No
            // 
            this.lbl_Sup_Inv_No.AutoSize = true;
            this.lbl_Sup_Inv_No.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sup_Inv_No.Location = new System.Drawing.Point(364, 24);
            this.lbl_Sup_Inv_No.Name = "lbl_Sup_Inv_No";
            this.lbl_Sup_Inv_No.Size = new System.Drawing.Size(142, 25);
            this.lbl_Sup_Inv_No.TabIndex = 27;
            this.lbl_Sup_Inv_No.Text = "Sup. Inv. No ";
            // 
            // gb_Product_Details
            // 
            this.gb_Product_Details.BackColor = System.Drawing.Color.Transparent;
            this.gb_Product_Details.Controls.Add(this.dtp_Purchase_Date);
            this.gb_Product_Details.Controls.Add(this.lbl_Purchase_Date);
            this.gb_Product_Details.Controls.Add(this.tb_Sales_Price);
            this.gb_Product_Details.Controls.Add(this.label1);
            this.gb_Product_Details.Controls.Add(this.tb_Purchase_Price);
            this.gb_Product_Details.Controls.Add(this.lbl_Purchase_Price);
            this.gb_Product_Details.Controls.Add(this.tb_Quantity);
            this.gb_Product_Details.Controls.Add(this.lbl_Quantity);
            this.gb_Product_Details.Controls.Add(this.tb_Purchase_Unit);
            this.gb_Product_Details.Controls.Add(this.lbl_Purchase_Unit);
            this.gb_Product_Details.Controls.Add(this.btn_Add);
            this.gb_Product_Details.Controls.Add(this.tb_Product_Name);
            this.gb_Product_Details.Controls.Add(this.lbl_Product_Name);
            this.gb_Product_Details.Controls.Add(this.cmb_Subcategory_Name);
            this.gb_Product_Details.Controls.Add(this.lbl_Subcategory_Name);
            this.gb_Product_Details.Controls.Add(this.Cmb_Category_Name);
            this.gb_Product_Details.Controls.Add(this.lbl_Category_Name);
            this.gb_Product_Details.Font = new System.Drawing.Font("Cambria", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Product_Details.Location = new System.Drawing.Point(0, 74);
            this.gb_Product_Details.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gb_Product_Details.Name = "gb_Product_Details";
            this.gb_Product_Details.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gb_Product_Details.Size = new System.Drawing.Size(1280, 180);
            this.gb_Product_Details.TabIndex = 29;
            this.gb_Product_Details.TabStop = false;
            this.gb_Product_Details.Text = "Product Details";
            // 
            // dtp_Purchase_Date
            // 
            this.dtp_Purchase_Date.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Purchase_Date.Location = new System.Drawing.Point(997, 130);
            this.dtp_Purchase_Date.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtp_Purchase_Date.Name = "dtp_Purchase_Date";
            this.dtp_Purchase_Date.Size = new System.Drawing.Size(255, 34);
            this.dtp_Purchase_Date.TabIndex = 29;
            // 
            // lbl_Purchase_Date
            // 
            this.lbl_Purchase_Date.AutoSize = true;
            this.lbl_Purchase_Date.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Purchase_Date.Location = new System.Drawing.Point(817, 134);
            this.lbl_Purchase_Date.Name = "lbl_Purchase_Date";
            this.lbl_Purchase_Date.Size = new System.Drawing.Size(166, 25);
            this.lbl_Purchase_Date.TabIndex = 28;
            this.lbl_Purchase_Date.Text = "Purchase Date ";
            // 
            // tb_Sales_Price
            // 
            this.tb_Sales_Price.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Sales_Price.Location = new System.Drawing.Point(592, 130);
            this.tb_Sales_Price.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Sales_Price.Name = "tb_Sales_Price";
            this.tb_Sales_Price.Size = new System.Drawing.Size(211, 34);
            this.tb_Sales_Price.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(452, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 25);
            this.label1.TabIndex = 26;
            this.label1.Text = "Sales Price ";
            // 
            // tb_Purchase_Price
            // 
            this.tb_Purchase_Price.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Purchase_Price.Location = new System.Drawing.Point(213, 130);
            this.tb_Purchase_Price.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Purchase_Price.Name = "tb_Purchase_Price";
            this.tb_Purchase_Price.Size = new System.Drawing.Size(221, 34);
            this.tb_Purchase_Price.TabIndex = 25;
            // 
            // lbl_Purchase_Price
            // 
            this.lbl_Purchase_Price.AutoSize = true;
            this.lbl_Purchase_Price.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Purchase_Price.Location = new System.Drawing.Point(27, 134);
            this.lbl_Purchase_Price.Name = "lbl_Purchase_Price";
            this.lbl_Purchase_Price.Size = new System.Drawing.Size(170, 25);
            this.lbl_Purchase_Price.TabIndex = 24;
            this.lbl_Purchase_Price.Text = "Purchase Price ";
            // 
            // tb_Quantity
            // 
            this.tb_Quantity.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Quantity.Location = new System.Drawing.Point(621, 78);
            this.tb_Quantity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Quantity.Name = "tb_Quantity";
            this.tb_Quantity.Size = new System.Drawing.Size(181, 34);
            this.tb_Quantity.TabIndex = 23;
            // 
            // lbl_Quantity
            // 
            this.lbl_Quantity.AutoSize = true;
            this.lbl_Quantity.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Quantity.Location = new System.Drawing.Point(501, 81);
            this.lbl_Quantity.Name = "lbl_Quantity";
            this.lbl_Quantity.Size = new System.Drawing.Size(106, 25);
            this.lbl_Quantity.TabIndex = 22;
            this.lbl_Quantity.Text = "Quantity ";
            // 
            // tb_Purchase_Unit
            // 
            this.tb_Purchase_Unit.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Purchase_Unit.Location = new System.Drawing.Point(997, 75);
            this.tb_Purchase_Unit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Purchase_Unit.Name = "tb_Purchase_Unit";
            this.tb_Purchase_Unit.Size = new System.Drawing.Size(255, 34);
            this.tb_Purchase_Unit.TabIndex = 21;
            // 
            // lbl_Purchase_Unit
            // 
            this.lbl_Purchase_Unit.AutoSize = true;
            this.lbl_Purchase_Unit.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Purchase_Unit.Location = new System.Drawing.Point(821, 78);
            this.lbl_Purchase_Unit.Name = "lbl_Purchase_Unit";
            this.lbl_Purchase_Unit.Size = new System.Drawing.Size(161, 25);
            this.lbl_Purchase_Unit.TabIndex = 20;
            this.lbl_Purchase_Unit.Text = "Purchase Unit ";
            // 
            // btn_Add
            // 
            this.btn_Add.BackColor = System.Drawing.Color.LightSalmon;
            this.btn_Add.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.Location = new System.Drawing.Point(1104, 17);
            this.btn_Add.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(148, 46);
            this.btn_Add.TabIndex = 19;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = false;
            // 
            // tb_Product_Name
            // 
            this.tb_Product_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Product_Name.Location = new System.Drawing.Point(213, 78);
            this.tb_Product_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Product_Name.Name = "tb_Product_Name";
            this.tb_Product_Name.Size = new System.Drawing.Size(273, 34);
            this.tb_Product_Name.TabIndex = 15;
            // 
            // lbl_Product_Name
            // 
            this.lbl_Product_Name.AutoSize = true;
            this.lbl_Product_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product_Name.Location = new System.Drawing.Point(31, 81);
            this.lbl_Product_Name.Name = "lbl_Product_Name";
            this.lbl_Product_Name.Size = new System.Drawing.Size(165, 25);
            this.lbl_Product_Name.TabIndex = 14;
            this.lbl_Product_Name.Text = "Product Name ";
            // 
            // cmb_Subcategory_Name
            // 
            this.cmb_Subcategory_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Subcategory_Name.FormattingEnabled = true;
            this.cmb_Subcategory_Name.Location = new System.Drawing.Point(793, 25);
            this.cmb_Subcategory_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmb_Subcategory_Name.Name = "cmb_Subcategory_Name";
            this.cmb_Subcategory_Name.Size = new System.Drawing.Size(305, 34);
            this.cmb_Subcategory_Name.TabIndex = 13;
            // 
            // lbl_Subcategory_Name
            // 
            this.lbl_Subcategory_Name.AutoSize = true;
            this.lbl_Subcategory_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subcategory_Name.Location = new System.Drawing.Point(578, 28);
            this.lbl_Subcategory_Name.Name = "lbl_Subcategory_Name";
            this.lbl_Subcategory_Name.Size = new System.Drawing.Size(209, 25);
            this.lbl_Subcategory_Name.TabIndex = 12;
            this.lbl_Subcategory_Name.Text = "Subcategory Name ";
            // 
            // Cmb_Category_Name
            // 
            this.Cmb_Category_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cmb_Category_Name.FormattingEnabled = true;
            this.Cmb_Category_Name.Location = new System.Drawing.Point(215, 25);
            this.Cmb_Category_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Cmb_Category_Name.Name = "Cmb_Category_Name";
            this.Cmb_Category_Name.Size = new System.Drawing.Size(333, 34);
            this.Cmb_Category_Name.TabIndex = 11;
            // 
            // lbl_Category_Name
            // 
            this.lbl_Category_Name.AutoSize = true;
            this.lbl_Category_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category_Name.Location = new System.Drawing.Point(33, 30);
            this.lbl_Category_Name.Name = "lbl_Category_Name";
            this.lbl_Category_Name.Size = new System.Drawing.Size(176, 25);
            this.lbl_Category_Name.TabIndex = 10;
            this.lbl_Category_Name.Text = "Category Name ";
            // 
            // dgv_Purchase_Bill
            // 
            this.dgv_Purchase_Bill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Purchase_Bill.Location = new System.Drawing.Point(15, 258);
            this.dgv_Purchase_Bill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgv_Purchase_Bill.Name = "dgv_Purchase_Bill";
            this.dgv_Purchase_Bill.RowHeadersWidth = 51;
            this.dgv_Purchase_Bill.RowTemplate.Height = 24;
            this.dgv_Purchase_Bill.Size = new System.Drawing.Size(1245, 249);
            this.dgv_Purchase_Bill.TabIndex = 30;
            // 
            // tb_Discount
            // 
            this.tb_Discount.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Discount.Location = new System.Drawing.Point(212, 529);
            this.tb_Discount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Discount.Name = "tb_Discount";
            this.tb_Discount.Size = new System.Drawing.Size(181, 34);
            this.tb_Discount.TabIndex = 32;
            // 
            // lbl_Discount
            // 
            this.lbl_Discount.AutoSize = true;
            this.lbl_Discount.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Discount.Location = new System.Drawing.Point(92, 532);
            this.lbl_Discount.Name = "lbl_Discount";
            this.lbl_Discount.Size = new System.Drawing.Size(106, 25);
            this.lbl_Discount.TabIndex = 31;
            this.lbl_Discount.Text = "Discount ";
            // 
            // lbl_GST
            // 
            this.lbl_GST.AutoSize = true;
            this.lbl_GST.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GST.Location = new System.Drawing.Point(515, 538);
            this.lbl_GST.Name = "lbl_GST";
            this.lbl_GST.Size = new System.Drawing.Size(64, 25);
            this.lbl_GST.TabIndex = 31;
            this.lbl_GST.Text = "GST ";
            // 
            // tb_GST
            // 
            this.tb_GST.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_GST.Location = new System.Drawing.Point(597, 529);
            this.tb_GST.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_GST.Name = "tb_GST";
            this.tb_GST.Size = new System.Drawing.Size(225, 34);
            this.tb_GST.TabIndex = 32;
            // 
            // lbl_Total_Amount
            // 
            this.lbl_Total_Amount.AutoSize = true;
            this.lbl_Total_Amount.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total_Amount.Location = new System.Drawing.Point(857, 532);
            this.lbl_Total_Amount.Name = "lbl_Total_Amount";
            this.lbl_Total_Amount.Size = new System.Drawing.Size(154, 25);
            this.lbl_Total_Amount.TabIndex = 31;
            this.lbl_Total_Amount.Text = "Total Amount ";
            // 
            // tb_Total_Amount
            // 
            this.tb_Total_Amount.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Total_Amount.Location = new System.Drawing.Point(1021, 529);
            this.tb_Total_Amount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Total_Amount.Name = "tb_Total_Amount";
            this.tb_Total_Amount.Size = new System.Drawing.Size(223, 34);
            this.tb_Total_Amount.TabIndex = 32;
            // 
            // lbl_Paid_Amount
            // 
            this.lbl_Paid_Amount.AutoSize = true;
            this.lbl_Paid_Amount.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Paid_Amount.Location = new System.Drawing.Point(49, 585);
            this.lbl_Paid_Amount.Name = "lbl_Paid_Amount";
            this.lbl_Paid_Amount.Size = new System.Drawing.Size(149, 25);
            this.lbl_Paid_Amount.TabIndex = 31;
            this.lbl_Paid_Amount.Text = "Paid Amount ";
            // 
            // tb_Paid_Amount
            // 
            this.tb_Paid_Amount.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Paid_Amount.Location = new System.Drawing.Point(212, 581);
            this.tb_Paid_Amount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Paid_Amount.Name = "tb_Paid_Amount";
            this.tb_Paid_Amount.Size = new System.Drawing.Size(181, 34);
            this.tb_Paid_Amount.TabIndex = 32;
            // 
            // tb_Balance_Amount
            // 
            this.tb_Balance_Amount.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Balance_Amount.Location = new System.Drawing.Point(597, 585);
            this.tb_Balance_Amount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Balance_Amount.Name = "tb_Balance_Amount";
            this.tb_Balance_Amount.Size = new System.Drawing.Size(225, 34);
            this.tb_Balance_Amount.TabIndex = 34;
            // 
            // lbl_Balance_Amount
            // 
            this.lbl_Balance_Amount.AutoSize = true;
            this.lbl_Balance_Amount.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Balance_Amount.Location = new System.Drawing.Point(399, 585);
            this.lbl_Balance_Amount.Name = "lbl_Balance_Amount";
            this.lbl_Balance_Amount.Size = new System.Drawing.Size(184, 25);
            this.lbl_Balance_Amount.TabIndex = 33;
            this.lbl_Balance_Amount.Text = "Balance Amount ";
            // 
            // cmb_Payment_Mode
            // 
            this.cmb_Payment_Mode.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Payment_Mode.FormattingEnabled = true;
            this.cmb_Payment_Mode.Location = new System.Drawing.Point(1021, 585);
            this.cmb_Payment_Mode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmb_Payment_Mode.Name = "cmb_Payment_Mode";
            this.cmb_Payment_Mode.Size = new System.Drawing.Size(223, 34);
            this.cmb_Payment_Mode.TabIndex = 36;
            // 
            // lbl_Payment_Mode
            // 
            this.lbl_Payment_Mode.AutoSize = true;
            this.lbl_Payment_Mode.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Payment_Mode.Location = new System.Drawing.Point(839, 591);
            this.lbl_Payment_Mode.Name = "lbl_Payment_Mode";
            this.lbl_Payment_Mode.Size = new System.Drawing.Size(172, 25);
            this.lbl_Payment_Mode.TabIndex = 35;
            this.lbl_Payment_Mode.Text = "Payment Mode ";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.LightSalmon;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(336, 654);
            this.btn_Save.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(125, 48);
            this.btn_Save.TabIndex = 37;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // btn_Order_List
            // 
            this.btn_Order_List.BackColor = System.Drawing.Color.LightSalmon;
            this.btn_Order_List.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Order_List.Location = new System.Drawing.Point(844, 654);
            this.btn_Order_List.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Order_List.Name = "btn_Order_List";
            this.btn_Order_List.Size = new System.Drawing.Size(166, 48);
            this.btn_Order_List.TabIndex = 38;
            this.btn_Order_List.Text = "Order List";
            this.btn_Order_List.UseVisualStyleBackColor = false;
            // 
            // Frm_Purchase_Bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1285, 703);
            this.Controls.Add(this.btn_Order_List);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.cmb_Payment_Mode);
            this.Controls.Add(this.lbl_Payment_Mode);
            this.Controls.Add(this.tb_Balance_Amount);
            this.Controls.Add(this.lbl_Balance_Amount);
            this.Controls.Add(this.tb_Total_Amount);
            this.Controls.Add(this.lbl_Total_Amount);
            this.Controls.Add(this.tb_GST);
            this.Controls.Add(this.lbl_GST);
            this.Controls.Add(this.tb_Paid_Amount);
            this.Controls.Add(this.lbl_Paid_Amount);
            this.Controls.Add(this.tb_Discount);
            this.Controls.Add(this.lbl_Discount);
            this.Controls.Add(this.dgv_Purchase_Bill);
            this.Controls.Add(this.gb_Product_Details);
            this.Controls.Add(this.tb_Sup_Inv_No);
            this.Controls.Add(this.lbl_Sup_Inv_No);
            this.Controls.Add(this.tb_Supplier_Name);
            this.Controls.Add(this.lbl_Supplier_Name);
            this.Controls.Add(this.tb_Purchase_ID);
            this.Controls.Add(this.lbl_Purchase_ID);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Frm_Purchase_Bill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Purchase Bill";
            this.gb_Product_Details.ResumeLayout(false);
            this.gb_Product_Details.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Purchase_Bill)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Supplier_Name;
        private System.Windows.Forms.Label lbl_Supplier_Name;
        private System.Windows.Forms.TextBox tb_Purchase_ID;
        private System.Windows.Forms.Label lbl_Purchase_ID;
        private System.Windows.Forms.TextBox tb_Sup_Inv_No;
        private System.Windows.Forms.Label lbl_Sup_Inv_No;
        private System.Windows.Forms.GroupBox gb_Product_Details;
        private System.Windows.Forms.TextBox tb_Sales_Price;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_Purchase_Price;
        private System.Windows.Forms.Label lbl_Purchase_Price;
        private System.Windows.Forms.TextBox tb_Quantity;
        private System.Windows.Forms.Label lbl_Quantity;
        private System.Windows.Forms.TextBox tb_Purchase_Unit;
        private System.Windows.Forms.Label lbl_Purchase_Unit;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.TextBox tb_Product_Name;
        private System.Windows.Forms.Label lbl_Product_Name;
        private System.Windows.Forms.ComboBox cmb_Subcategory_Name;
        private System.Windows.Forms.Label lbl_Subcategory_Name;
        private System.Windows.Forms.ComboBox Cmb_Category_Name;
        private System.Windows.Forms.Label lbl_Category_Name;
        private System.Windows.Forms.DateTimePicker dtp_Purchase_Date;
        private System.Windows.Forms.Label lbl_Purchase_Date;
        private System.Windows.Forms.DataGridView dgv_Purchase_Bill;
        private System.Windows.Forms.TextBox tb_Discount;
        private System.Windows.Forms.Label lbl_Discount;
        private System.Windows.Forms.Label lbl_GST;
        private System.Windows.Forms.TextBox tb_GST;
        private System.Windows.Forms.Label lbl_Total_Amount;
        private System.Windows.Forms.TextBox tb_Total_Amount;
        private System.Windows.Forms.Label lbl_Paid_Amount;
        private System.Windows.Forms.TextBox tb_Paid_Amount;
        private System.Windows.Forms.TextBox tb_Balance_Amount;
        private System.Windows.Forms.Label lbl_Balance_Amount;
        private System.Windows.Forms.ComboBox cmb_Payment_Mode;
        private System.Windows.Forms.Label lbl_Payment_Mode;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Order_List;
    }
}