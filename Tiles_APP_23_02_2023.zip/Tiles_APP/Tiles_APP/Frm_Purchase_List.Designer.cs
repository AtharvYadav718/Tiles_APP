﻿namespace Tiles_APP
{
    partial class Frm_Purchase_List
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Product_Name = new System.Windows.Forms.TextBox();
            this.lbl_Product_Name = new System.Windows.Forms.Label();
            this.tb_Purchase_ID = new System.Windows.Forms.TextBox();
            this.lbl_Purchase_ID = new System.Windows.Forms.Label();
            this.cmb_Suplier_Name = new System.Windows.Forms.ComboBox();
            this.lbl_Supplier_Name = new System.Windows.Forms.Label();
            this.tb_Total_Amount = new System.Windows.Forms.TextBox();
            this.lbl_Total_Amount = new System.Windows.Forms.Label();
            this.btn_Search = new System.Windows.Forms.Button();
            this.dgv_Quotation = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Quotation)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_Product_Name
            // 
            this.tb_Product_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Product_Name.Location = new System.Drawing.Point(211, 92);
            this.tb_Product_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Product_Name.Name = "tb_Product_Name";
            this.tb_Product_Name.Size = new System.Drawing.Size(405, 39);
            this.tb_Product_Name.TabIndex = 20;
            // 
            // lbl_Product_Name
            // 
            this.lbl_Product_Name.AutoSize = true;
            this.lbl_Product_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product_Name.Location = new System.Drawing.Point(12, 92);
            this.lbl_Product_Name.Name = "lbl_Product_Name";
            this.lbl_Product_Name.Size = new System.Drawing.Size(185, 32);
            this.lbl_Product_Name.TabIndex = 19;
            this.lbl_Product_Name.Text = "Product Name";
            // 
            // tb_Purchase_ID
            // 
            this.tb_Purchase_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Purchase_ID.Location = new System.Drawing.Point(211, 21);
            this.tb_Purchase_ID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Purchase_ID.Name = "tb_Purchase_ID";
            this.tb_Purchase_ID.Size = new System.Drawing.Size(184, 39);
            this.tb_Purchase_ID.TabIndex = 18;
            // 
            // lbl_Purchase_ID
            // 
            this.lbl_Purchase_ID.AutoSize = true;
            this.lbl_Purchase_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Purchase_ID.Location = new System.Drawing.Point(15, 25);
            this.lbl_Purchase_ID.Name = "lbl_Purchase_ID";
            this.lbl_Purchase_ID.Size = new System.Drawing.Size(168, 32);
            this.lbl_Purchase_ID.TabIndex = 17;
            this.lbl_Purchase_ID.Text = "Purchase ID ";
            // 
            // cmb_Suplier_Name
            // 
            this.cmb_Suplier_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Suplier_Name.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmb_Suplier_Name.FormattingEnabled = true;
            this.cmb_Suplier_Name.Location = new System.Drawing.Point(698, 21);
            this.cmb_Suplier_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmb_Suplier_Name.Name = "cmb_Suplier_Name";
            this.cmb_Suplier_Name.Size = new System.Drawing.Size(368, 39);
            this.cmb_Suplier_Name.TabIndex = 22;
            // 
            // lbl_Supplier_Name
            // 
            this.lbl_Supplier_Name.AutoSize = true;
            this.lbl_Supplier_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Supplier_Name.Location = new System.Drawing.Point(505, 23);
            this.lbl_Supplier_Name.Name = "lbl_Supplier_Name";
            this.lbl_Supplier_Name.Size = new System.Drawing.Size(176, 32);
            this.lbl_Supplier_Name.TabIndex = 21;
            this.lbl_Supplier_Name.Text = "Suplier Name";
            // 
            // tb_Total_Amount
            // 
            this.tb_Total_Amount.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Total_Amount.Location = new System.Drawing.Point(883, 90);
            this.tb_Total_Amount.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Total_Amount.Name = "tb_Total_Amount";
            this.tb_Total_Amount.Size = new System.Drawing.Size(183, 39);
            this.tb_Total_Amount.TabIndex = 28;
            // 
            // lbl_Total_Amount
            // 
            this.lbl_Total_Amount.AutoSize = true;
            this.lbl_Total_Amount.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total_Amount.Location = new System.Drawing.Point(692, 92);
            this.lbl_Total_Amount.Name = "lbl_Total_Amount";
            this.lbl_Total_Amount.Size = new System.Drawing.Size(183, 32);
            this.lbl_Total_Amount.TabIndex = 27;
            this.lbl_Total_Amount.Text = "Total Amount ";
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.LightSalmon;
            this.btn_Search.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.Location = new System.Drawing.Point(1111, 47);
            this.btn_Search.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(157, 50);
            this.btn_Search.TabIndex = 29;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            // 
            // dgv_Quotation
            // 
            this.dgv_Quotation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Quotation.Location = new System.Drawing.Point(18, 158);
            this.dgv_Quotation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgv_Quotation.Name = "dgv_Quotation";
            this.dgv_Quotation.RowHeadersWidth = 51;
            this.dgv_Quotation.RowTemplate.Height = 24;
            this.dgv_Quotation.Size = new System.Drawing.Size(1237, 534);
            this.dgv_Quotation.TabIndex = 30;
            // 
            // Frm_Purchase_List
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1285, 703);
            this.Controls.Add(this.dgv_Quotation);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.tb_Total_Amount);
            this.Controls.Add(this.lbl_Total_Amount);
            this.Controls.Add(this.cmb_Suplier_Name);
            this.Controls.Add(this.lbl_Supplier_Name);
            this.Controls.Add(this.tb_Product_Name);
            this.Controls.Add(this.lbl_Product_Name);
            this.Controls.Add(this.tb_Purchase_ID);
            this.Controls.Add(this.lbl_Purchase_ID);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Frm_Purchase_List";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Purchase List";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Quotation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Product_Name;
        private System.Windows.Forms.Label lbl_Product_Name;
        private System.Windows.Forms.TextBox tb_Purchase_ID;
        private System.Windows.Forms.Label lbl_Purchase_ID;
        private System.Windows.Forms.ComboBox cmb_Suplier_Name;
        private System.Windows.Forms.Label lbl_Supplier_Name;
        private System.Windows.Forms.TextBox tb_Total_Amount;
        private System.Windows.Forms.Label lbl_Total_Amount;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.DataGridView dgv_Quotation;
    }
}