﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiles_APP
{
    public partial class Frm_Tiles_APP_Login : Form
    {
        public Frm_Tiles_APP_Login()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            Frm_Menu_Form obj = new Frm_Menu_Form();
            this.Hide();
            obj.Show();

            Tiles_App_Sherard_Content.Con_Open();

            Tiles_App_Sherard_Content.Con_Close();  
        }
    }
}
