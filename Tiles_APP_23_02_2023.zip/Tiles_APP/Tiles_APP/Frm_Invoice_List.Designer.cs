﻿namespace Tiles_APP
{
    partial class Frm_Invoice_List
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_Invoice_List = new System.Windows.Forms.DataGridView();
            this.btn_Search = new System.Windows.Forms.Button();
            this.tb_Custmer_Name = new System.Windows.Forms.TextBox();
            this.lbl_Customer_Name = new System.Windows.Forms.Label();
            this.tb_Invoice_ID = new System.Windows.Forms.TextBox();
            this.lbl_Invoice_ID = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Invoice_List)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_Invoice_List
            // 
            this.dgv_Invoice_List.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Invoice_List.Location = new System.Drawing.Point(12, 111);
            this.dgv_Invoice_List.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgv_Invoice_List.Name = "dgv_Invoice_List";
            this.dgv_Invoice_List.RowHeadersWidth = 51;
            this.dgv_Invoice_List.RowTemplate.Height = 24;
            this.dgv_Invoice_List.Size = new System.Drawing.Size(1249, 585);
            this.dgv_Invoice_List.TabIndex = 29;
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.LightSalmon;
            this.btn_Search.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.Location = new System.Drawing.Point(1143, 30);
            this.btn_Search.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(127, 47);
            this.btn_Search.TabIndex = 28;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            // 
            // tb_Custmer_Name
            // 
            this.tb_Custmer_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Custmer_Name.Location = new System.Drawing.Point(703, 34);
            this.tb_Custmer_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Custmer_Name.Name = "tb_Custmer_Name";
            this.tb_Custmer_Name.Size = new System.Drawing.Size(415, 39);
            this.tb_Custmer_Name.TabIndex = 27;
            // 
            // lbl_Customer_Name
            // 
            this.lbl_Customer_Name.AutoSize = true;
            this.lbl_Customer_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Name.Location = new System.Drawing.Point(451, 38);
            this.lbl_Customer_Name.Name = "lbl_Customer_Name";
            this.lbl_Customer_Name.Size = new System.Drawing.Size(219, 35);
            this.lbl_Customer_Name.TabIndex = 26;
            this.lbl_Customer_Name.Text = "Customer Name";
            // 
            // tb_Invoice_ID
            // 
            this.tb_Invoice_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Invoice_ID.Location = new System.Drawing.Point(197, 34);
            this.tb_Invoice_ID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_Invoice_ID.Name = "tb_Invoice_ID";
            this.tb_Invoice_ID.Size = new System.Drawing.Size(215, 39);
            this.tb_Invoice_ID.TabIndex = 25;
            // 
            // lbl_Invoice_ID
            // 
            this.lbl_Invoice_ID.AutoSize = true;
            this.lbl_Invoice_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Invoice_ID.Location = new System.Drawing.Point(15, 33);
            this.lbl_Invoice_ID.Name = "lbl_Invoice_ID";
            this.lbl_Invoice_ID.Size = new System.Drawing.Size(156, 35);
            this.lbl_Invoice_ID.TabIndex = 24;
            this.lbl_Invoice_ID.Text = "Invoice ID ";
            // 
            // Frm_Invoice_List
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1285, 703);
            this.Controls.Add(this.dgv_Invoice_List);
            this.Controls.Add(this.btn_Search);
            this.Controls.Add(this.tb_Custmer_Name);
            this.Controls.Add(this.lbl_Customer_Name);
            this.Controls.Add(this.tb_Invoice_ID);
            this.Controls.Add(this.lbl_Invoice_ID);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Frm_Invoice_List";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Invoice List";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Invoice_List)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Invoice_List;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.TextBox tb_Custmer_Name;
        private System.Windows.Forms.Label lbl_Customer_Name;
        private System.Windows.Forms.TextBox tb_Invoice_ID;
        private System.Windows.Forms.Label lbl_Invoice_ID;
    }
}