﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tiles_APP
{
    class Tiles_App_Sherard_Content
    {
        
        public static SqlConnection Con = new SqlConnection(@"Data Source=ATHARV;Initial Catalog=Tiles_APP_DB;Integrated Security=True");

        public static void Con_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }

        }

        public static void Con_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }

        }

        public static int Auto_Incr(string Table_Name, string ID_Field_Name, int Start_Point)
        {
            Con_Open();

            int Cnt = 0;

            SqlCommand cmd = new SqlCommand();

            cmd.Connection = Con;
            cmd.CommandText = "Select Count (*) From " + Table_Name + "";

            Cnt = Convert.ToInt32(cmd.ExecuteScalar());

            if(Cnt > 0)
            {
                cmd.Dispose();

                cmd.Connection = Con;
                cmd.CommandText = "Select Max(" + ID_Field_Name + ") From" + Table_Name + "";

                Cnt = Convert.ToInt32(cmd.ExecuteScalar()) ;

                Cnt += 1;
            }
            else
            {
                Cnt = Start_Point;
            }
            return Cnt;
            Con_Close();
        }
    }
}