﻿namespace Tiles_APP
{
    partial class Frm_Add_New_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Save = new System.Windows.Forms.Button();
            this.tb_Sales_Rate = new System.Windows.Forms.TextBox();
            this.lbl_Sales_Rate = new System.Windows.Forms.Label();
            this.tb_GST = new System.Windows.Forms.TextBox();
            this.lbl_GST = new System.Windows.Forms.Label();
            this.tb_Stock_Quantity = new System.Windows.Forms.TextBox();
            this.lbl_Stock_Quantity = new System.Windows.Forms.Label();
            this.tb_Purchase_Rate = new System.Windows.Forms.TextBox();
            this.lbl_Purchase_Rate = new System.Windows.Forms.Label();
            this.tb_Email_ID = new System.Windows.Forms.TextBox();
            this.lbl_Supplier_Name = new System.Windows.Forms.Label();
            this.tb_Aadhar_No = new System.Windows.Forms.TextBox();
            this.lbl_Product_Name = new System.Windows.Forms.Label();
            this.dtp_Tie_Up_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_Category_Name = new System.Windows.Forms.Label();
            this.tb_Supplier_ID = new System.Windows.Forms.TextBox();
            this.lbl_Product_ID = new System.Windows.Forms.Label();
            this.lbl_Subcategory_Name = new System.Windows.Forms.Label();
            this.cmb_Subcategory_Name = new System.Windows.Forms.ComboBox();
            this.Cmb_Category_Name = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.LightSalmon;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(598, 514);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(157, 72);
            this.btn_Save.TabIndex = 75;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // tb_Sales_Rate
            // 
            this.tb_Sales_Rate.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Sales_Rate.Location = new System.Drawing.Point(905, 214);
            this.tb_Sales_Rate.Name = "tb_Sales_Rate";
            this.tb_Sales_Rate.Size = new System.Drawing.Size(355, 39);
            this.tb_Sales_Rate.TabIndex = 74;
            // 
            // lbl_Sales_Rate
            // 
            this.lbl_Sales_Rate.AutoSize = true;
            this.lbl_Sales_Rate.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Sales_Rate.Location = new System.Drawing.Point(737, 218);
            this.lbl_Sales_Rate.Name = "lbl_Sales_Rate";
            this.lbl_Sales_Rate.Size = new System.Drawing.Size(164, 35);
            this.lbl_Sales_Rate.TabIndex = 69;
            this.lbl_Sales_Rate.Text = "Sales Rate :";
            // 
            // tb_GST
            // 
            this.tb_GST.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_GST.Location = new System.Drawing.Point(905, 401);
            this.tb_GST.Name = "tb_GST";
            this.tb_GST.Size = new System.Drawing.Size(355, 39);
            this.tb_GST.TabIndex = 73;
            // 
            // lbl_GST
            // 
            this.lbl_GST.AutoSize = true;
            this.lbl_GST.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GST.Location = new System.Drawing.Point(807, 400);
            this.lbl_GST.Name = "lbl_GST";
            this.lbl_GST.Size = new System.Drawing.Size(92, 35);
            this.lbl_GST.TabIndex = 68;
            this.lbl_GST.Text = "GST :";
            // 
            // tb_Stock_Quantity
            // 
            this.tb_Stock_Quantity.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Stock_Quantity.Location = new System.Drawing.Point(905, 299);
            this.tb_Stock_Quantity.Name = "tb_Stock_Quantity";
            this.tb_Stock_Quantity.Size = new System.Drawing.Size(355, 39);
            this.tb_Stock_Quantity.TabIndex = 72;
            // 
            // lbl_Stock_Quantity
            // 
            this.lbl_Stock_Quantity.AutoSize = true;
            this.lbl_Stock_Quantity.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Stock_Quantity.Location = new System.Drawing.Point(681, 303);
            this.lbl_Stock_Quantity.Name = "lbl_Stock_Quantity";
            this.lbl_Stock_Quantity.Size = new System.Drawing.Size(222, 35);
            this.lbl_Stock_Quantity.TabIndex = 67;
            this.lbl_Stock_Quantity.Text = "Stock Quantity :";
            // 
            // tb_Purchase_Rate
            // 
            this.tb_Purchase_Rate.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Purchase_Rate.Location = new System.Drawing.Point(905, 140);
            this.tb_Purchase_Rate.Name = "tb_Purchase_Rate";
            this.tb_Purchase_Rate.Size = new System.Drawing.Size(355, 39);
            this.tb_Purchase_Rate.TabIndex = 71;
            // 
            // lbl_Purchase_Rate
            // 
            this.lbl_Purchase_Rate.AutoSize = true;
            this.lbl_Purchase_Rate.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Purchase_Rate.Location = new System.Drawing.Point(682, 140);
            this.lbl_Purchase_Rate.Name = "lbl_Purchase_Rate";
            this.lbl_Purchase_Rate.Size = new System.Drawing.Size(214, 35);
            this.lbl_Purchase_Rate.TabIndex = 70;
            this.lbl_Purchase_Rate.Text = "Purchase Rate :";
            // 
            // tb_Email_ID
            // 
            this.tb_Email_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Email_ID.Location = new System.Drawing.Point(291, 397);
            this.tb_Email_ID.Name = "tb_Email_ID";
            this.tb_Email_ID.Size = new System.Drawing.Size(368, 39);
            this.tb_Email_ID.TabIndex = 66;
            // 
            // lbl_Supplier_Name
            // 
            this.lbl_Supplier_Name.AutoSize = true;
            this.lbl_Supplier_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Supplier_Name.Location = new System.Drawing.Point(57, 396);
            this.lbl_Supplier_Name.Name = "lbl_Supplier_Name";
            this.lbl_Supplier_Name.Size = new System.Drawing.Size(221, 35);
            this.lbl_Supplier_Name.TabIndex = 65;
            this.lbl_Supplier_Name.Text = "Supplier Name :";
            // 
            // tb_Aadhar_No
            // 
            this.tb_Aadhar_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Aadhar_No.Location = new System.Drawing.Point(291, 306);
            this.tb_Aadhar_No.Name = "tb_Aadhar_No";
            this.tb_Aadhar_No.Size = new System.Drawing.Size(368, 39);
            this.tb_Aadhar_No.TabIndex = 64;
            // 
            // lbl_Product_Name
            // 
            this.lbl_Product_Name.AutoSize = true;
            this.lbl_Product_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product_Name.Location = new System.Drawing.Point(63, 306);
            this.lbl_Product_Name.Name = "lbl_Product_Name";
            this.lbl_Product_Name.Size = new System.Drawing.Size(215, 35);
            this.lbl_Product_Name.TabIndex = 63;
            this.lbl_Product_Name.Text = "Product Name :";
            // 
            // dtp_Tie_Up_Date
            // 
            this.dtp_Tie_Up_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Tie_Up_Date.Location = new System.Drawing.Point(905, 60);
            this.dtp_Tie_Up_Date.Name = "dtp_Tie_Up_Date";
            this.dtp_Tie_Up_Date.Size = new System.Drawing.Size(355, 39);
            this.dtp_Tie_Up_Date.TabIndex = 62;
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.Location = new System.Drawing.Point(811, 60);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(92, 35);
            this.lbl_Date.TabIndex = 61;
            this.lbl_Date.Text = "Date :";
            // 
            // lbl_Category_Name
            // 
            this.lbl_Category_Name.AutoSize = true;
            this.lbl_Category_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category_Name.Location = new System.Drawing.Point(49, 139);
            this.lbl_Category_Name.Name = "lbl_Category_Name";
            this.lbl_Category_Name.Size = new System.Drawing.Size(229, 35);
            this.lbl_Category_Name.TabIndex = 59;
            this.lbl_Category_Name.Text = "Category Name :";
            // 
            // tb_Supplier_ID
            // 
            this.tb_Supplier_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Supplier_ID.Location = new System.Drawing.Point(291, 60);
            this.tb_Supplier_ID.Name = "tb_Supplier_ID";
            this.tb_Supplier_ID.Size = new System.Drawing.Size(368, 39);
            this.tb_Supplier_ID.TabIndex = 58;
            // 
            // lbl_Product_ID
            // 
            this.lbl_Product_ID.AutoSize = true;
            this.lbl_Product_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product_ID.Location = new System.Drawing.Point(105, 59);
            this.lbl_Product_ID.Name = "lbl_Product_ID";
            this.lbl_Product_ID.Size = new System.Drawing.Size(176, 35);
            this.lbl_Product_ID.TabIndex = 57;
            this.lbl_Product_ID.Text = "Product ID :";
            // 
            // lbl_Subcategory_Name
            // 
            this.lbl_Subcategory_Name.AutoSize = true;
            this.lbl_Subcategory_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subcategory_Name.Location = new System.Drawing.Point(8, 222);
            this.lbl_Subcategory_Name.Name = "lbl_Subcategory_Name";
            this.lbl_Subcategory_Name.Size = new System.Drawing.Size(270, 35);
            this.lbl_Subcategory_Name.TabIndex = 59;
            this.lbl_Subcategory_Name.Text = "Subcategory Name :";
            // 
            // cmb_Subcategory_Name
            // 
            this.cmb_Subcategory_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Subcategory_Name.FormattingEnabled = true;
            this.cmb_Subcategory_Name.Location = new System.Drawing.Point(291, 223);
            this.cmb_Subcategory_Name.Name = "cmb_Subcategory_Name";
            this.cmb_Subcategory_Name.Size = new System.Drawing.Size(368, 39);
            this.cmb_Subcategory_Name.TabIndex = 77;
            // 
            // Cmb_Category_Name
            // 
            this.Cmb_Category_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cmb_Category_Name.FormattingEnabled = true;
            this.Cmb_Category_Name.Location = new System.Drawing.Point(291, 144);
            this.Cmb_Category_Name.Name = "Cmb_Category_Name";
            this.Cmb_Category_Name.Size = new System.Drawing.Size(368, 39);
            this.Cmb_Category_Name.TabIndex = 76;
            // 
            // Frm_Add_New_Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1282, 653);
            this.Controls.Add(this.cmb_Subcategory_Name);
            this.Controls.Add(this.Cmb_Category_Name);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.tb_Sales_Rate);
            this.Controls.Add(this.lbl_Sales_Rate);
            this.Controls.Add(this.tb_GST);
            this.Controls.Add(this.lbl_GST);
            this.Controls.Add(this.tb_Stock_Quantity);
            this.Controls.Add(this.lbl_Stock_Quantity);
            this.Controls.Add(this.tb_Purchase_Rate);
            this.Controls.Add(this.lbl_Purchase_Rate);
            this.Controls.Add(this.tb_Email_ID);
            this.Controls.Add(this.lbl_Supplier_Name);
            this.Controls.Add(this.tb_Aadhar_No);
            this.Controls.Add(this.lbl_Product_Name);
            this.Controls.Add(this.dtp_Tie_Up_Date);
            this.Controls.Add(this.lbl_Date);
            this.Controls.Add(this.lbl_Subcategory_Name);
            this.Controls.Add(this.lbl_Category_Name);
            this.Controls.Add(this.tb_Supplier_ID);
            this.Controls.Add(this.lbl_Product_ID);
            this.Name = "Frm_Add_New_Product";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Product";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox tb_Sales_Rate;
        private System.Windows.Forms.Label lbl_Sales_Rate;
        private System.Windows.Forms.TextBox tb_GST;
        private System.Windows.Forms.Label lbl_GST;
        private System.Windows.Forms.TextBox tb_Stock_Quantity;
        private System.Windows.Forms.Label lbl_Stock_Quantity;
        private System.Windows.Forms.TextBox tb_Purchase_Rate;
        private System.Windows.Forms.Label lbl_Purchase_Rate;
        private System.Windows.Forms.TextBox tb_Email_ID;
        private System.Windows.Forms.Label lbl_Supplier_Name;
        private System.Windows.Forms.TextBox tb_Aadhar_No;
        private System.Windows.Forms.Label lbl_Product_Name;
        private System.Windows.Forms.DateTimePicker dtp_Tie_Up_Date;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Category_Name;
        private System.Windows.Forms.TextBox tb_Supplier_ID;
        private System.Windows.Forms.Label lbl_Product_ID;
        private System.Windows.Forms.Label lbl_Subcategory_Name;
        private System.Windows.Forms.ComboBox cmb_Subcategory_Name;
        private System.Windows.Forms.ComboBox Cmb_Category_Name;
    }
}