﻿namespace Tiles_APP
{
    partial class Frm_Add_New_Supplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Save = new System.Windows.Forms.Button();
            this.tb_Alternative_Mob_No = new System.Windows.Forms.TextBox();
            this.lbl_Altternative_Mob_No = new System.Windows.Forms.Label();
            this.tb_PAN_No = new System.Windows.Forms.TextBox();
            this.lbl_PAN_No = new System.Windows.Forms.Label();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.tb_Email_ID = new System.Windows.Forms.TextBox();
            this.lbl_Email_ID = new System.Windows.Forms.Label();
            this.tb_Aadhar_No = new System.Windows.Forms.TextBox();
            this.lbl_Aadhar_No = new System.Windows.Forms.Label();
            this.dtp_Tie_Up_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_Tie_Up_Date = new System.Windows.Forms.Label();
            this.tb_Custmer_Name = new System.Windows.Forms.TextBox();
            this.lbl_Supplier_Name = new System.Windows.Forms.Label();
            this.tb_Supplier_ID = new System.Windows.Forms.TextBox();
            this.lbl_Supplier_ID = new System.Windows.Forms.Label();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.LightSalmon;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(575, 563);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(157, 61);
            this.btn_Save.TabIndex = 54;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // tb_Alternative_Mob_No
            // 
            this.tb_Alternative_Mob_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Alternative_Mob_No.Location = new System.Drawing.Point(915, 154);
            this.tb_Alternative_Mob_No.Name = "tb_Alternative_Mob_No";
            this.tb_Alternative_Mob_No.Size = new System.Drawing.Size(355, 39);
            this.tb_Alternative_Mob_No.TabIndex = 53;
            // 
            // lbl_Altternative_Mob_No
            // 
            this.lbl_Altternative_Mob_No.AutoSize = true;
            this.lbl_Altternative_Mob_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Altternative_Mob_No.Location = new System.Drawing.Point(630, 163);
            this.lbl_Altternative_Mob_No.Name = "lbl_Altternative_Mob_No";
            this.lbl_Altternative_Mob_No.Size = new System.Drawing.Size(285, 35);
            this.lbl_Altternative_Mob_No.TabIndex = 48;
            this.lbl_Altternative_Mob_No.Text = "Alternative Mob.No :";
            // 
            // tb_PAN_No
            // 
            this.tb_PAN_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_PAN_No.Location = new System.Drawing.Point(915, 320);
            this.tb_PAN_No.Name = "tb_PAN_No";
            this.tb_PAN_No.Size = new System.Drawing.Size(355, 39);
            this.tb_PAN_No.TabIndex = 52;
            // 
            // lbl_PAN_No
            // 
            this.lbl_PAN_No.AutoSize = true;
            this.lbl_PAN_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PAN_No.Location = new System.Drawing.Point(771, 324);
            this.lbl_PAN_No.Name = "lbl_PAN_No";
            this.lbl_PAN_No.Size = new System.Drawing.Size(138, 35);
            this.lbl_PAN_No.TabIndex = 47;
            this.lbl_PAN_No.Text = "PAN No :";
            // 
            // tb_Address
            // 
            this.tb_Address.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Address.Location = new System.Drawing.Point(915, 241);
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(355, 39);
            this.tb_Address.TabIndex = 51;
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.Location = new System.Drawing.Point(773, 240);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(136, 35);
            this.lbl_Address.TabIndex = 46;
            this.lbl_Address.Text = "Address :";
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(915, 76);
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(355, 39);
            this.tb_Mobile_No.TabIndex = 50;
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.Location = new System.Drawing.Point(742, 85);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(167, 35);
            this.lbl_Mobile_No.TabIndex = 49;
            this.lbl_Mobile_No.Text = "Mobile No :";
            // 
            // tb_Email_ID
            // 
            this.tb_Email_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Email_ID.Location = new System.Drawing.Point(247, 406);
            this.tb_Email_ID.Name = "tb_Email_ID";
            this.tb_Email_ID.Size = new System.Drawing.Size(368, 39);
            this.tb_Email_ID.TabIndex = 45;
            // 
            // lbl_Email_ID
            // 
            this.lbl_Email_ID.AutoSize = true;
            this.lbl_Email_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email_ID.Location = new System.Drawing.Point(62, 406);
            this.lbl_Email_ID.Name = "lbl_Email_ID";
            this.lbl_Email_ID.Size = new System.Drawing.Size(163, 35);
            this.lbl_Email_ID.TabIndex = 44;
            this.lbl_Email_ID.Text = "E-Mail ID :";
            // 
            // tb_Aadhar_No
            // 
            this.tb_Aadhar_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Aadhar_No.Location = new System.Drawing.Point(247, 325);
            this.tb_Aadhar_No.Name = "tb_Aadhar_No";
            this.tb_Aadhar_No.Size = new System.Drawing.Size(368, 39);
            this.tb_Aadhar_No.TabIndex = 43;
            // 
            // lbl_Aadhar_No
            // 
            this.lbl_Aadhar_No.AutoSize = true;
            this.lbl_Aadhar_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aadhar_No.Location = new System.Drawing.Point(54, 325);
            this.lbl_Aadhar_No.Name = "lbl_Aadhar_No";
            this.lbl_Aadhar_No.Size = new System.Drawing.Size(171, 35);
            this.lbl_Aadhar_No.TabIndex = 42;
            this.lbl_Aadhar_No.Text = "Aadhar No :";
            // 
            // dtp_Tie_Up_Date
            // 
            this.dtp_Tie_Up_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Tie_Up_Date.Location = new System.Drawing.Point(247, 243);
            this.dtp_Tie_Up_Date.Name = "dtp_Tie_Up_Date";
            this.dtp_Tie_Up_Date.Size = new System.Drawing.Size(368, 39);
            this.dtp_Tie_Up_Date.TabIndex = 41;
            // 
            // lbl_Tie_Up_Date
            // 
            this.lbl_Tie_Up_Date.AutoSize = true;
            this.lbl_Tie_Up_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tie_Up_Date.Location = new System.Drawing.Point(31, 245);
            this.lbl_Tie_Up_Date.Name = "lbl_Tie_Up_Date";
            this.lbl_Tie_Up_Date.Size = new System.Drawing.Size(194, 35);
            this.lbl_Tie_Up_Date.TabIndex = 40;
            this.lbl_Tie_Up_Date.Text = " Tie Up Date :";
            // 
            // tb_Custmer_Name
            // 
            this.tb_Custmer_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Custmer_Name.Location = new System.Drawing.Point(247, 159);
            this.tb_Custmer_Name.Name = "tb_Custmer_Name";
            this.tb_Custmer_Name.Size = new System.Drawing.Size(368, 39);
            this.tb_Custmer_Name.TabIndex = 39;
            // 
            // lbl_Supplier_Name
            // 
            this.lbl_Supplier_Name.AutoSize = true;
            this.lbl_Supplier_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Supplier_Name.Location = new System.Drawing.Point(4, 158);
            this.lbl_Supplier_Name.Name = "lbl_Supplier_Name";
            this.lbl_Supplier_Name.Size = new System.Drawing.Size(221, 35);
            this.lbl_Supplier_Name.TabIndex = 38;
            this.lbl_Supplier_Name.Text = "Supplier Name :";
            // 
            // tb_Supplier_ID
            // 
            this.tb_Supplier_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Supplier_ID.Location = new System.Drawing.Point(247, 81);
            this.tb_Supplier_ID.Name = "tb_Supplier_ID";
            this.tb_Supplier_ID.Size = new System.Drawing.Size(368, 39);
            this.tb_Supplier_ID.TabIndex = 37;
            // 
            // lbl_Supplier_ID
            // 
            this.lbl_Supplier_ID.AutoSize = true;
            this.lbl_Supplier_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Supplier_ID.Location = new System.Drawing.Point(43, 80);
            this.lbl_Supplier_ID.Name = "lbl_Supplier_ID";
            this.lbl_Supplier_ID.Size = new System.Drawing.Size(182, 35);
            this.lbl_Supplier_ID.TabIndex = 36;
            this.lbl_Supplier_ID.Text = "Supplier ID :";
            // 
            // lbl_Note
            // 
            this.lbl_Note.AutoSize = true;
            this.lbl_Note.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Note.Location = new System.Drawing.Point(816, 406);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(93, 35);
            this.lbl_Note.TabIndex = 55;
            this.lbl_Note.Text = "Note :";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(915, 407);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(355, 115);
            this.textBox1.TabIndex = 56;
            // 
            // Frm_Add_New_Supplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1282, 653);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbl_Note);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.tb_Alternative_Mob_No);
            this.Controls.Add(this.lbl_Altternative_Mob_No);
            this.Controls.Add(this.tb_PAN_No);
            this.Controls.Add(this.lbl_PAN_No);
            this.Controls.Add(this.tb_Address);
            this.Controls.Add(this.lbl_Address);
            this.Controls.Add(this.tb_Mobile_No);
            this.Controls.Add(this.lbl_Mobile_No);
            this.Controls.Add(this.tb_Email_ID);
            this.Controls.Add(this.lbl_Email_ID);
            this.Controls.Add(this.tb_Aadhar_No);
            this.Controls.Add(this.lbl_Aadhar_No);
            this.Controls.Add(this.dtp_Tie_Up_Date);
            this.Controls.Add(this.lbl_Tie_Up_Date);
            this.Controls.Add(this.tb_Custmer_Name);
            this.Controls.Add(this.lbl_Supplier_Name);
            this.Controls.Add(this.tb_Supplier_ID);
            this.Controls.Add(this.lbl_Supplier_ID);
            this.Name = "Frm_Add_New_Supplier";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Supplier";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox tb_Alternative_Mob_No;
        private System.Windows.Forms.Label lbl_Altternative_Mob_No;
        private System.Windows.Forms.TextBox tb_PAN_No;
        private System.Windows.Forms.Label lbl_PAN_No;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.TextBox tb_Email_ID;
        private System.Windows.Forms.Label lbl_Email_ID;
        private System.Windows.Forms.TextBox tb_Aadhar_No;
        private System.Windows.Forms.Label lbl_Aadhar_No;
        private System.Windows.Forms.DateTimePicker dtp_Tie_Up_Date;
        private System.Windows.Forms.Label lbl_Tie_Up_Date;
        private System.Windows.Forms.TextBox tb_Custmer_Name;
        private System.Windows.Forms.Label lbl_Supplier_Name;
        private System.Windows.Forms.TextBox tb_Supplier_ID;
        private System.Windows.Forms.Label lbl_Supplier_ID;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.TextBox textBox1;
    }
}