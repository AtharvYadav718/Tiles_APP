﻿namespace Tiles_APP
{
    partial class Frm_Menu_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Sidemenu = new System.Windows.Forms.Panel();
            this.pnl_Stock_Submenu = new System.Windows.Forms.Panel();
            this.btn_Button_04 = new System.Windows.Forms.Button();
            this.btn_Button_03 = new System.Windows.Forms.Button();
            this.btn_Dead_Stock = new System.Windows.Forms.Button();
            this.btn_Remaining_Stock = new System.Windows.Forms.Button();
            this.btn_Stock = new System.Windows.Forms.Button();
            this.pnl_Sale_Submenu = new System.Windows.Forms.Panel();
            this.btn_Quotation_List = new System.Windows.Forms.Button();
            this.btn_Quotation = new System.Windows.Forms.Button();
            this.btn_Invoice_List = new System.Windows.Forms.Button();
            this.btn_Invoice = new System.Windows.Forms.Button();
            this.btn_Sale = new System.Windows.Forms.Button();
            this.pnl_Purchase_Submenu = new System.Windows.Forms.Panel();
            this.btn_Button_02 = new System.Windows.Forms.Button();
            this.btn_Button_01 = new System.Windows.Forms.Button();
            this.btn_Purchase_Bill_List = new System.Windows.Forms.Button();
            this.btn_Purchase_Bill = new System.Windows.Forms.Button();
            this.btn_Purchase = new System.Windows.Forms.Button();
            this.pnl_Master_Submenu = new System.Windows.Forms.Panel();
            this.btn_Regular_Customer = new System.Windows.Forms.Button();
            this.btn_Product_Information = new System.Windows.Forms.Button();
            this.btn_Supplier_Information = new System.Windows.Forms.Button();
            this.btn_Customer_Information = new System.Windows.Forms.Button();
            this.btn_Master = new System.Windows.Forms.Button();
            this.pnl_Logo = new System.Windows.Forms.Panel();
            this.pnl_Head = new System.Windows.Forms.Panel();
            this.lbl_Head = new System.Windows.Forms.Label();
            this.pnl_ChildForm = new System.Windows.Forms.Panel();
            this.pnl_Sidemenu.SuspendLayout();
            this.pnl_Stock_Submenu.SuspendLayout();
            this.pnl_Sale_Submenu.SuspendLayout();
            this.pnl_Purchase_Submenu.SuspendLayout();
            this.pnl_Master_Submenu.SuspendLayout();
            this.pnl_Head.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Sidemenu
            // 
            this.pnl_Sidemenu.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnl_Sidemenu.Controls.Add(this.pnl_Stock_Submenu);
            this.pnl_Sidemenu.Controls.Add(this.btn_Stock);
            this.pnl_Sidemenu.Controls.Add(this.pnl_Sale_Submenu);
            this.pnl_Sidemenu.Controls.Add(this.btn_Sale);
            this.pnl_Sidemenu.Controls.Add(this.pnl_Purchase_Submenu);
            this.pnl_Sidemenu.Controls.Add(this.btn_Purchase);
            this.pnl_Sidemenu.Controls.Add(this.pnl_Master_Submenu);
            this.pnl_Sidemenu.Controls.Add(this.btn_Master);
            this.pnl_Sidemenu.Controls.Add(this.pnl_Logo);
            this.pnl_Sidemenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_Sidemenu.Location = new System.Drawing.Point(0, 0);
            this.pnl_Sidemenu.Name = "pnl_Sidemenu";
            this.pnl_Sidemenu.Size = new System.Drawing.Size(267, 783);
            this.pnl_Sidemenu.TabIndex = 0;
            // 
            // pnl_Stock_Submenu
            // 
            this.pnl_Stock_Submenu.BackColor = System.Drawing.Color.LightSteelBlue;
            this.pnl_Stock_Submenu.Controls.Add(this.btn_Button_04);
            this.pnl_Stock_Submenu.Controls.Add(this.btn_Button_03);
            this.pnl_Stock_Submenu.Controls.Add(this.btn_Dead_Stock);
            this.pnl_Stock_Submenu.Controls.Add(this.btn_Remaining_Stock);
            this.pnl_Stock_Submenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Stock_Submenu.Location = new System.Drawing.Point(0, 799);
            this.pnl_Stock_Submenu.Name = "pnl_Stock_Submenu";
            this.pnl_Stock_Submenu.Size = new System.Drawing.Size(267, 166);
            this.pnl_Stock_Submenu.TabIndex = 8;
            // 
            // btn_Button_04
            // 
            this.btn_Button_04.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Button_04.FlatAppearance.BorderSize = 0;
            this.btn_Button_04.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Button_04.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Button_04.Location = new System.Drawing.Point(0, 120);
            this.btn_Button_04.Name = "btn_Button_04";
            this.btn_Button_04.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Button_04.Size = new System.Drawing.Size(267, 40);
            this.btn_Button_04.TabIndex = 3;
            this.btn_Button_04.Text = "Button 04";
            this.btn_Button_04.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Button_04.UseVisualStyleBackColor = true;
            this.btn_Button_04.Click += new System.EventHandler(this.btn_Button_04_Click);
            // 
            // btn_Button_03
            // 
            this.btn_Button_03.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Button_03.FlatAppearance.BorderSize = 0;
            this.btn_Button_03.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Button_03.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Button_03.Location = new System.Drawing.Point(0, 80);
            this.btn_Button_03.Name = "btn_Button_03";
            this.btn_Button_03.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Button_03.Size = new System.Drawing.Size(267, 40);
            this.btn_Button_03.TabIndex = 2;
            this.btn_Button_03.Text = "Button 03";
            this.btn_Button_03.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Button_03.UseVisualStyleBackColor = true;
            this.btn_Button_03.Click += new System.EventHandler(this.btn_Button_03_Click);
            // 
            // btn_Dead_Stock
            // 
            this.btn_Dead_Stock.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Dead_Stock.FlatAppearance.BorderSize = 0;
            this.btn_Dead_Stock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Dead_Stock.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dead_Stock.Location = new System.Drawing.Point(0, 40);
            this.btn_Dead_Stock.Name = "btn_Dead_Stock";
            this.btn_Dead_Stock.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Dead_Stock.Size = new System.Drawing.Size(267, 40);
            this.btn_Dead_Stock.TabIndex = 1;
            this.btn_Dead_Stock.Text = "Dead Stock";
            this.btn_Dead_Stock.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Dead_Stock.UseVisualStyleBackColor = true;
            this.btn_Dead_Stock.Click += new System.EventHandler(this.btn_Dead_Stock_Click);
            // 
            // btn_Remaining_Stock
            // 
            this.btn_Remaining_Stock.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Remaining_Stock.FlatAppearance.BorderSize = 0;
            this.btn_Remaining_Stock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Remaining_Stock.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Remaining_Stock.Location = new System.Drawing.Point(0, 0);
            this.btn_Remaining_Stock.Name = "btn_Remaining_Stock";
            this.btn_Remaining_Stock.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Remaining_Stock.Size = new System.Drawing.Size(267, 40);
            this.btn_Remaining_Stock.TabIndex = 0;
            this.btn_Remaining_Stock.Text = "Remaining Stock";
            this.btn_Remaining_Stock.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Remaining_Stock.UseVisualStyleBackColor = true;
            this.btn_Remaining_Stock.Click += new System.EventHandler(this.btn_Remaining_Stock_Click);
            // 
            // btn_Stock
            // 
            this.btn_Stock.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Stock.FlatAppearance.BorderSize = 0;
            this.btn_Stock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Stock.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Stock.ForeColor = System.Drawing.Color.Black;
            this.btn_Stock.Location = new System.Drawing.Point(0, 754);
            this.btn_Stock.Name = "btn_Stock";
            this.btn_Stock.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Stock.Size = new System.Drawing.Size(267, 45);
            this.btn_Stock.TabIndex = 7;
            this.btn_Stock.Text = "Stock";
            this.btn_Stock.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Stock.UseVisualStyleBackColor = true;
            this.btn_Stock.Click += new System.EventHandler(this.btn_Stock_Click);
            // 
            // pnl_Sale_Submenu
            // 
            this.pnl_Sale_Submenu.BackColor = System.Drawing.Color.LightSteelBlue;
            this.pnl_Sale_Submenu.Controls.Add(this.btn_Quotation_List);
            this.pnl_Sale_Submenu.Controls.Add(this.btn_Quotation);
            this.pnl_Sale_Submenu.Controls.Add(this.btn_Invoice_List);
            this.pnl_Sale_Submenu.Controls.Add(this.btn_Invoice);
            this.pnl_Sale_Submenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Sale_Submenu.Location = new System.Drawing.Point(0, 583);
            this.pnl_Sale_Submenu.Name = "pnl_Sale_Submenu";
            this.pnl_Sale_Submenu.Size = new System.Drawing.Size(267, 171);
            this.pnl_Sale_Submenu.TabIndex = 6;
            // 
            // btn_Quotation_List
            // 
            this.btn_Quotation_List.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Quotation_List.FlatAppearance.BorderSize = 0;
            this.btn_Quotation_List.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Quotation_List.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Quotation_List.Location = new System.Drawing.Point(0, 120);
            this.btn_Quotation_List.Name = "btn_Quotation_List";
            this.btn_Quotation_List.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Quotation_List.Size = new System.Drawing.Size(267, 40);
            this.btn_Quotation_List.TabIndex = 3;
            this.btn_Quotation_List.Text = "Quotation List";
            this.btn_Quotation_List.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Quotation_List.UseVisualStyleBackColor = true;
            this.btn_Quotation_List.Click += new System.EventHandler(this.btn_Quotation_List_Click);
            // 
            // btn_Quotation
            // 
            this.btn_Quotation.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Quotation.FlatAppearance.BorderSize = 0;
            this.btn_Quotation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Quotation.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Quotation.Location = new System.Drawing.Point(0, 80);
            this.btn_Quotation.Name = "btn_Quotation";
            this.btn_Quotation.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Quotation.Size = new System.Drawing.Size(267, 40);
            this.btn_Quotation.TabIndex = 2;
            this.btn_Quotation.Text = "Quotation";
            this.btn_Quotation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Quotation.UseVisualStyleBackColor = true;
            this.btn_Quotation.Click += new System.EventHandler(this.btn_Quotation_Click);
            // 
            // btn_Invoice_List
            // 
            this.btn_Invoice_List.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Invoice_List.FlatAppearance.BorderSize = 0;
            this.btn_Invoice_List.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Invoice_List.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Invoice_List.Location = new System.Drawing.Point(0, 40);
            this.btn_Invoice_List.Name = "btn_Invoice_List";
            this.btn_Invoice_List.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Invoice_List.Size = new System.Drawing.Size(267, 40);
            this.btn_Invoice_List.TabIndex = 1;
            this.btn_Invoice_List.Text = "Invoice List";
            this.btn_Invoice_List.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Invoice_List.UseVisualStyleBackColor = true;
            this.btn_Invoice_List.Click += new System.EventHandler(this.btn_Invoice_List_Click);
            // 
            // btn_Invoice
            // 
            this.btn_Invoice.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Invoice.FlatAppearance.BorderSize = 0;
            this.btn_Invoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Invoice.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Invoice.Location = new System.Drawing.Point(0, 0);
            this.btn_Invoice.Name = "btn_Invoice";
            this.btn_Invoice.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Invoice.Size = new System.Drawing.Size(267, 40);
            this.btn_Invoice.TabIndex = 0;
            this.btn_Invoice.Text = "Invoice";
            this.btn_Invoice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Invoice.UseVisualStyleBackColor = true;
            this.btn_Invoice.Click += new System.EventHandler(this.btn_Invoice_Click);
            // 
            // btn_Sale
            // 
            this.btn_Sale.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Sale.FlatAppearance.BorderSize = 0;
            this.btn_Sale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Sale.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sale.ForeColor = System.Drawing.Color.Black;
            this.btn_Sale.Location = new System.Drawing.Point(0, 538);
            this.btn_Sale.Name = "btn_Sale";
            this.btn_Sale.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Sale.Size = new System.Drawing.Size(267, 45);
            this.btn_Sale.TabIndex = 5;
            this.btn_Sale.Text = "Sale";
            this.btn_Sale.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Sale.UseVisualStyleBackColor = true;
            this.btn_Sale.Click += new System.EventHandler(this.btn_Sale_Click);
            // 
            // pnl_Purchase_Submenu
            // 
            this.pnl_Purchase_Submenu.BackColor = System.Drawing.Color.LightSteelBlue;
            this.pnl_Purchase_Submenu.Controls.Add(this.btn_Button_02);
            this.pnl_Purchase_Submenu.Controls.Add(this.btn_Button_01);
            this.pnl_Purchase_Submenu.Controls.Add(this.btn_Purchase_Bill_List);
            this.pnl_Purchase_Submenu.Controls.Add(this.btn_Purchase_Bill);
            this.pnl_Purchase_Submenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Purchase_Submenu.Location = new System.Drawing.Point(0, 372);
            this.pnl_Purchase_Submenu.Name = "pnl_Purchase_Submenu";
            this.pnl_Purchase_Submenu.Size = new System.Drawing.Size(267, 166);
            this.pnl_Purchase_Submenu.TabIndex = 4;
            // 
            // btn_Button_02
            // 
            this.btn_Button_02.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Button_02.FlatAppearance.BorderSize = 0;
            this.btn_Button_02.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Button_02.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Button_02.Location = new System.Drawing.Point(0, 120);
            this.btn_Button_02.Name = "btn_Button_02";
            this.btn_Button_02.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Button_02.Size = new System.Drawing.Size(267, 40);
            this.btn_Button_02.TabIndex = 3;
            this.btn_Button_02.Text = "Button 02";
            this.btn_Button_02.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Button_02.UseVisualStyleBackColor = true;
            this.btn_Button_02.Click += new System.EventHandler(this.btn_Button_02_Click);
            // 
            // btn_Button_01
            // 
            this.btn_Button_01.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Button_01.FlatAppearance.BorderSize = 0;
            this.btn_Button_01.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Button_01.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Button_01.Location = new System.Drawing.Point(0, 80);
            this.btn_Button_01.Name = "btn_Button_01";
            this.btn_Button_01.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Button_01.Size = new System.Drawing.Size(267, 40);
            this.btn_Button_01.TabIndex = 2;
            this.btn_Button_01.Text = "Button 01";
            this.btn_Button_01.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Button_01.UseVisualStyleBackColor = true;
            this.btn_Button_01.Click += new System.EventHandler(this.btn_Button_01_Click);
            // 
            // btn_Purchase_Bill_List
            // 
            this.btn_Purchase_Bill_List.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Purchase_Bill_List.FlatAppearance.BorderSize = 0;
            this.btn_Purchase_Bill_List.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Purchase_Bill_List.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Purchase_Bill_List.Location = new System.Drawing.Point(0, 40);
            this.btn_Purchase_Bill_List.Name = "btn_Purchase_Bill_List";
            this.btn_Purchase_Bill_List.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Purchase_Bill_List.Size = new System.Drawing.Size(267, 40);
            this.btn_Purchase_Bill_List.TabIndex = 1;
            this.btn_Purchase_Bill_List.Text = "Purchase Bill List";
            this.btn_Purchase_Bill_List.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Purchase_Bill_List.UseVisualStyleBackColor = true;
            this.btn_Purchase_Bill_List.Click += new System.EventHandler(this.btn_Purchase_Bill_List_Click);
            // 
            // btn_Purchase_Bill
            // 
            this.btn_Purchase_Bill.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Purchase_Bill.FlatAppearance.BorderSize = 0;
            this.btn_Purchase_Bill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Purchase_Bill.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Purchase_Bill.Location = new System.Drawing.Point(0, 0);
            this.btn_Purchase_Bill.Name = "btn_Purchase_Bill";
            this.btn_Purchase_Bill.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Purchase_Bill.Size = new System.Drawing.Size(267, 40);
            this.btn_Purchase_Bill.TabIndex = 0;
            this.btn_Purchase_Bill.Text = "Purchase Bill";
            this.btn_Purchase_Bill.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Purchase_Bill.UseVisualStyleBackColor = true;
            this.btn_Purchase_Bill.Click += new System.EventHandler(this.btn_Purchase_Bill_Click);
            // 
            // btn_Purchase
            // 
            this.btn_Purchase.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Purchase.FlatAppearance.BorderSize = 0;
            this.btn_Purchase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Purchase.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Purchase.ForeColor = System.Drawing.Color.Black;
            this.btn_Purchase.Location = new System.Drawing.Point(0, 327);
            this.btn_Purchase.Name = "btn_Purchase";
            this.btn_Purchase.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Purchase.Size = new System.Drawing.Size(267, 45);
            this.btn_Purchase.TabIndex = 3;
            this.btn_Purchase.Text = "Purchase";
            this.btn_Purchase.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Purchase.UseVisualStyleBackColor = true;
            this.btn_Purchase.Click += new System.EventHandler(this.btn_Purchase_Click);
            // 
            // pnl_Master_Submenu
            // 
            this.pnl_Master_Submenu.BackColor = System.Drawing.Color.LightSteelBlue;
            this.pnl_Master_Submenu.Controls.Add(this.btn_Regular_Customer);
            this.pnl_Master_Submenu.Controls.Add(this.btn_Product_Information);
            this.pnl_Master_Submenu.Controls.Add(this.btn_Supplier_Information);
            this.pnl_Master_Submenu.Controls.Add(this.btn_Customer_Information);
            this.pnl_Master_Submenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Master_Submenu.Location = new System.Drawing.Point(0, 161);
            this.pnl_Master_Submenu.Name = "pnl_Master_Submenu";
            this.pnl_Master_Submenu.Size = new System.Drawing.Size(267, 166);
            this.pnl_Master_Submenu.TabIndex = 2;
            // 
            // btn_Regular_Customer
            // 
            this.btn_Regular_Customer.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Regular_Customer.FlatAppearance.BorderSize = 0;
            this.btn_Regular_Customer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Regular_Customer.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regular_Customer.Location = new System.Drawing.Point(0, 120);
            this.btn_Regular_Customer.Name = "btn_Regular_Customer";
            this.btn_Regular_Customer.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Regular_Customer.Size = new System.Drawing.Size(267, 40);
            this.btn_Regular_Customer.TabIndex = 3;
            this.btn_Regular_Customer.Text = "Regular Customer";
            this.btn_Regular_Customer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Regular_Customer.UseVisualStyleBackColor = true;
            this.btn_Regular_Customer.Click += new System.EventHandler(this.btn_Regular_Customer_Click);
            // 
            // btn_Product_Information
            // 
            this.btn_Product_Information.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Product_Information.FlatAppearance.BorderSize = 0;
            this.btn_Product_Information.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Product_Information.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Product_Information.Location = new System.Drawing.Point(0, 80);
            this.btn_Product_Information.Name = "btn_Product_Information";
            this.btn_Product_Information.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Product_Information.Size = new System.Drawing.Size(267, 40);
            this.btn_Product_Information.TabIndex = 2;
            this.btn_Product_Information.Text = "Product Information";
            this.btn_Product_Information.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Product_Information.UseVisualStyleBackColor = true;
            this.btn_Product_Information.Click += new System.EventHandler(this.btn_Product_Information_Click);
            // 
            // btn_Supplier_Information
            // 
            this.btn_Supplier_Information.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Supplier_Information.FlatAppearance.BorderSize = 0;
            this.btn_Supplier_Information.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Supplier_Information.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Supplier_Information.Location = new System.Drawing.Point(0, 40);
            this.btn_Supplier_Information.Name = "btn_Supplier_Information";
            this.btn_Supplier_Information.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.btn_Supplier_Information.Size = new System.Drawing.Size(267, 40);
            this.btn_Supplier_Information.TabIndex = 1;
            this.btn_Supplier_Information.Text = "Supplier Information";
            this.btn_Supplier_Information.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Supplier_Information.UseVisualStyleBackColor = true;
            this.btn_Supplier_Information.Click += new System.EventHandler(this.btn_Supplier_Information_Click);
            // 
            // btn_Customer_Information
            // 
            this.btn_Customer_Information.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Customer_Information.FlatAppearance.BorderSize = 0;
            this.btn_Customer_Information.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Customer_Information.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Customer_Information.Location = new System.Drawing.Point(0, 0);
            this.btn_Customer_Information.Name = "btn_Customer_Information";
            this.btn_Customer_Information.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btn_Customer_Information.Size = new System.Drawing.Size(267, 40);
            this.btn_Customer_Information.TabIndex = 0;
            this.btn_Customer_Information.Text = "Customer Information";
            this.btn_Customer_Information.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Customer_Information.UseVisualStyleBackColor = true;
            this.btn_Customer_Information.Click += new System.EventHandler(this.btn_Customer_Information_Click);
            // 
            // btn_Master
            // 
            this.btn_Master.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Master.FlatAppearance.BorderSize = 0;
            this.btn_Master.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Master.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Master.ForeColor = System.Drawing.Color.Black;
            this.btn_Master.Location = new System.Drawing.Point(0, 116);
            this.btn_Master.Name = "btn_Master";
            this.btn_Master.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Master.Size = new System.Drawing.Size(267, 45);
            this.btn_Master.TabIndex = 1;
            this.btn_Master.Text = "Master";
            this.btn_Master.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Master.UseVisualStyleBackColor = true;
            this.btn_Master.Click += new System.EventHandler(this.btn_Master_Click);
            // 
            // pnl_Logo
            // 
            this.pnl_Logo.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnl_Logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Logo.Location = new System.Drawing.Point(0, 0);
            this.pnl_Logo.Name = "pnl_Logo";
            this.pnl_Logo.Size = new System.Drawing.Size(267, 116);
            this.pnl_Logo.TabIndex = 0;
            // 
            // pnl_Head
            // 
            this.pnl_Head.BackColor = System.Drawing.Color.Moccasin;
            this.pnl_Head.Controls.Add(this.lbl_Head);
            this.pnl_Head.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Head.Location = new System.Drawing.Point(267, 0);
            this.pnl_Head.Name = "pnl_Head";
            this.pnl_Head.Size = new System.Drawing.Size(1415, 116);
            this.pnl_Head.TabIndex = 1;
            // 
            // lbl_Head
            // 
            this.lbl_Head.AutoSize = true;
            this.lbl_Head.Font = new System.Drawing.Font("Georgia", 36F, System.Drawing.FontStyle.Bold);
            this.lbl_Head.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbl_Head.Location = new System.Drawing.Point(364, 27);
            this.lbl_Head.Name = "lbl_Head";
            this.lbl_Head.Size = new System.Drawing.Size(322, 69);
            this.lbl_Head.TabIndex = 0;
            this.lbl_Head.Text = "Tiles APP";
            // 
            // pnl_ChildForm
            // 
            this.pnl_ChildForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_ChildForm.Location = new System.Drawing.Point(267, 116);
            this.pnl_ChildForm.Name = "pnl_ChildForm";
            this.pnl_ChildForm.Size = new System.Drawing.Size(1415, 667);
            this.pnl_ChildForm.TabIndex = 2;
            //this.pnl_ChildForm.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_ChildForm_Paint);
            // 
            // Frm_Menu_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1682, 783);
            this.Controls.Add(this.pnl_ChildForm);
            this.Controls.Add(this.pnl_Head);
            this.Controls.Add(this.pnl_Sidemenu);
            this.Name = "Frm_Menu_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu Form";
           // this.Load += new System.EventHandler(this.Frm_Menu_Form_Load);
            this.pnl_Sidemenu.ResumeLayout(false);
            this.pnl_Stock_Submenu.ResumeLayout(false);
            this.pnl_Sale_Submenu.ResumeLayout(false);
            this.pnl_Purchase_Submenu.ResumeLayout(false);
            this.pnl_Master_Submenu.ResumeLayout(false);
            this.pnl_Head.ResumeLayout(false);
            this.pnl_Head.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Sidemenu;
        private System.Windows.Forms.Panel pnl_Logo;
        private System.Windows.Forms.Button btn_Master;
        private System.Windows.Forms.Panel pnl_Master_Submenu;
        private System.Windows.Forms.Button btn_Regular_Customer;
        private System.Windows.Forms.Button btn_Product_Information;
        private System.Windows.Forms.Button btn_Supplier_Information;
        private System.Windows.Forms.Button btn_Customer_Information;
        private System.Windows.Forms.Panel pnl_Purchase_Submenu;
        private System.Windows.Forms.Button btn_Button_02;
        private System.Windows.Forms.Button btn_Button_01;
        private System.Windows.Forms.Button btn_Purchase_Bill_List;
        private System.Windows.Forms.Button btn_Purchase_Bill;
        private System.Windows.Forms.Button btn_Purchase;
        private System.Windows.Forms.Button btn_Sale;
        private System.Windows.Forms.Panel pnl_Sale_Submenu;
        private System.Windows.Forms.Button btn_Quotation_List;
        private System.Windows.Forms.Button btn_Quotation;
        private System.Windows.Forms.Button btn_Invoice_List;
        private System.Windows.Forms.Button btn_Invoice;
        private System.Windows.Forms.Button btn_Stock;
        private System.Windows.Forms.Panel pnl_Stock_Submenu;
        private System.Windows.Forms.Button btn_Button_04;
        private System.Windows.Forms.Button btn_Button_03;
        private System.Windows.Forms.Button btn_Dead_Stock;
        private System.Windows.Forms.Button btn_Remaining_Stock;
        private System.Windows.Forms.Panel pnl_Head;
        private System.Windows.Forms.Label lbl_Head;
        private System.Windows.Forms.Panel pnl_ChildForm;
    }
}